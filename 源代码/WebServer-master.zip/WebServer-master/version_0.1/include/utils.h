//
// Created by marvinle on 2019/2/1 12:07 PM.
//

#ifndef WEBSERVER_UTILS_H
#define WEBSERVER_UTILS_H

#include <string>

namespace util {
    using namespace std;
     std::string& ltrim(string &);
     std::string& rtrim(string &);
     std::string& trim(string &);
}

#endif //WEBSERVER_UTILS_H
